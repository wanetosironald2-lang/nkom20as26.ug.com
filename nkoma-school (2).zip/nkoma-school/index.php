<?php require_once __DIR__ . '/includes/header.php';

$slides = $pdo->query("SELECT * FROM slider WHERE is_active=1 ORDER BY sort_order ASC, id DESC")->fetchAll();
$latestNews = $pdo->query("SELECT * FROM news WHERE is_published=1 ORDER BY created_at DESC LIMIT 3")->fetchAll();
?>

<?php if ($slides): ?>
<section class="slider">
  <?php foreach ($slides as $i => $s): ?>
  <div class="slide <?= $i===0?'active':'' ?>" style="background-image:url('<?= SITE_URL ?>/uploads/slider/<?= e($s['image']) ?>')">
    <div class="slide-overlay">
      <div class="container">
        <h2><?= e($s['title']) ?></h2>
        <p><?= e($s['subtitle']) ?></p>
        <?php if ($s['link']): ?><a class="btn" href="<?= e($s['link']) ?>">Learn More</a><?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  <button class="slider-prev">&#10094;</button>
  <button class="slider-next">&#10095;</button>
</section>
<?php endif; ?>

<section class="section">
  <div class="container">
    
    <div class="welcome" style="display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;">
      
      <!-- The center image has been removed -->
      
      <h2 style="margin: 15px 0; font-size: 2.5rem; color: #1a237e;">WELCOME TO <?= e($schoolName) ?></h2>
      
      <p style="font-style: italic; font-weight: bold; color: #2e7d32; font-size: 1.5rem; margin-bottom: 25px;">
        HONESTY AND HARDWORK
      </p>
      
      <p style="max-width: 600px; line-height: 1.5; font-size: 1.1rem; color: #444;">
       <strong> We are committed to providing quality education that develops the whole student academically, morally and socially.</strong>
      </p>
      
      <div class="stats" style="margin-top: 40px; width: 100%; display: flex; justify-content: center; gap: 30px; flex-wrap: wrap;">
        <div><h3>30+</h3><p>Years of Excellence</p></div>
        <div><h3>1200+</h3><p>Students</p></div>
        <div><h3>60+</h3><p>Qualified Teachers</p></div>
        <div><h3>98%</h3><p>Pass Rate</p></div>
      </div>
      
    </div>
  </div>
</section>

<section class="cta">
  <div class="container">
    <h2>Join Our Community</h2>
    <p>Applications for the next academic year are now open!</p>
    <a href="<?= SITE_URL ?>/apply.php" class="btn">Apply Online</a>
    <a href="<?= SITE_URL ?>/track-application.php" class="btn btn-outline">Track Application</a>
  </div>
</section>

<!-- This script makes the slider images change automatically -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  const slides = document.querySelectorAll('.slide');
  
  // Only run if there is more than 1 image
  if (slides.length > 1) {
    let idx = 0;
    
    const show = i => {
      slides.forEach(s => s.classList.remove('active'));
      slides[i].classList.add('active');
      idx = i;
    };

    // Arrows clicking
    document.querySelector('.slider-next')?.addEventListener('click', () => show((idx+1) % slides.length));
    document.querySelector('.slider-prev')?.addEventListener('click', () => show((idx-1+slides.length) % slides.length));
    
    // Auto change every 4 seconds
    setInterval(() => show((idx+1) % slides.length), 4000);
  }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>