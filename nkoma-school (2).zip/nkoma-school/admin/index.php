<?php
// Redirect to the login page when someone visits the /admin/ folder
header("Location: login.php");
exit;
?>