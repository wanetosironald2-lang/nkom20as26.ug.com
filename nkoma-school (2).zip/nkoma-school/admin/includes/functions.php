<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Escape HTML
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

// Redirect
function redirect($url) {
    header("Location: $url");
    exit;
}

// CSRF Protection
function csrfToken() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function verifyCsrf() {
    if (!isset($_POST['csrf']) || $_POST['csrf'] !== ($_SESSION['csrf'] ?? '')) {
        die("CSRF token validation failed.");
    }
}

// Admin Check
function requireAdmin() {
    if (!isset($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }
}

// Get Settings
function getSetting($pdo, $key, $default = '') {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key=?");
    $stmt->execute([$key]);
    $res = $stmt->fetchColumn();
    return $res !== false ? $res : $default;
}

// File Uploader (Creates folders automatically and validates images)
function uploadImage($file, $folder) {
    if (empty($file['name']) || $file['error'] !== UPLOAD_ERR_OK) return '';
    
    // Allowed file types
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return '';

    // Ensure directory exists
    $dir = UPLOAD_PATH . $folder . '/';
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }

    // Generate unique filename
    $filename = time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $target = $dir . $filename;

    if (move_uploaded_file($file['tmp_name'], $target)) {
        return $filename;
    }
    return '';
}

// Slugify
function slugify($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    return strtolower($text) ?: 'n-a';
}

// Grade calculator
function gradeFromMarks($marks) {
    if ($marks >= 80) return 'A';
    if ($marks >= 70) return 'B';
    if ($marks >= 60) return 'C';
    if ($marks >= 50) return 'D';
    return 'F';
}
?>